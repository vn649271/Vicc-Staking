module.exports = {
  theme: {
    extend: {
      colors: {
        primary: "#D01961",
      },
    },
  },
  variants: {},
  plugins: [require("@tailwindcss/ui")],
};
